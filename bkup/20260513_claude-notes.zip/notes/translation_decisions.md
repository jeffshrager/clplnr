# Micro-Planner Translation Decisions (plnr.181 → clplnr_repo)

## FEXPR → Macro pattern

MacLisp FEXPRs receive their arguments unevaluated as a list. Translation:
```
(DEFUN FOO FEXPR (ARGS) BODY) →
  (defmacro foo (&rest args) `(foo-fn ',args))
  (defun foo-fn (args) body)
```
This preserves the unevaluated-argument semantics. Macros suppress evaluation; the
`',args` quotes the actual source arguments into the -fn call at macro-expansion time.

## Dynamic Variables: DECLARE SPECIAL → DEFVAR

MacLisp's `(DECLARE (SPECIAL x))` makes all subsequent PROG/LET bindings of `x` dynamic.
In CL, `(defvar x ...)` globally declares `x` special, so any `prog`/`let` binding of `x`
automatically creates a dynamic binding. All MacLisp SPECIAL vars become `defvar` globals
in `globals.lisp`.

**Key cross-function shared variables** (free variables accessed across function-call
boundaries that required `defvar` to enable dynamic scoping):
- `thx`, `thtype` — shared between `thass1` and `thtae`
- `thy`, `thy1` — shared between `thgoal-fn`/`thass1` and `thtae`
- `tha2`, `thz`, `thz1` — shared between `thgoal-fn` and `thtry`

## Computed GOTO → Cond dispatch

MacLisp `(GO (CAR THX))` computes a tag at runtime. CL requires literal tags.
Fixed in `thtry1` with explicit dispatch:
```lisp
(let ((tag (car thx)))
  (cond ((eq tag 'thnum) (go thnum))
        ((eq tag 'thdbf) (go thdbf))
        ((eq tag 'thtbf) (go thtbf))
        (t (error "Unknown THTRY1 tag: ~S" tag))))
```
The three possible tags (thnum, thdbf, thtbf) are all defined in the same PROG.

## ERRSET/ERR → handler-case/error + planner-fail condition

MacLisp `ERRSET` catches all errors. `ERR NIL` signals a continuable error (used to
exit pattern-match failures from deep in `thmatch2`).
```
(ERRSET expr) → (handler-case expr (error () nil)) — returns (list result) or nil
(ERR NIL)     → (error 'planner-fail)
```
The `planner-fail` condition class is defined in `compat.lisp`.

## *CATCH/*THROW → catch/throw

Direct CL equivalents — same semantics.

## Reader macro $ → set-macro-character with (stream char)

MacLisp: `(SSTATUS MACRO $ 'THREAD)` installs THREAD as reader for $`.
CL: `(set-macro-character #\$ #'thread)` where thread takes `(stream char)`.
The `char` arg (the `$` character itself) is ignored; we read the next char ourselves.

## SASSQ → sassq in compat.lisp

MacLisp `SASSQ` takes `(key alist default-fn)` — like ASSQ but calls default-fn (no args)
on miss. Implemented as `(or (assoc key alist :test #'eq) (funcall default-fn))`.

## ((PROG2 0. THEXP (SETQ THEXP NIL))) — zero-arg handler dispatch

In the original THVAL, handlers are dispatched via:
```
((PROG2 0. THEXP (SETQ THEXP NIL)))
```
This evaluates THEXP (a function name), clears THEXP, and calls the result (a zero-arg fn).
Translation: `(funcall (prog2 nil thexp (setq thexp nil)))`.

## DEFPROP → setf (get ...) in eval-when

MacLisp `(DEFPROP atom value indicator)` → `(setf (get 'atom 'indicator) 'value)`.
All dispatch table DEFPROP calls are in an `eval-when (:load-toplevel :execute)` block.

## Variable semantics in THGOAL patterns

- `$?X` = `(THV X)` — reference to EXISTING variable X. X must already be in THALIST.
- `$_X` = `(THNV X)` — new variable. X must ALSO be in THALIST (as THUNASSIGNED).
- Variables are added to THALIST by `(THPROG (X Y ...) body...)` via THBIND.
- Using `$?X` or `$_X` in a THGOAL without prior THPROG/THBIND → THUNBOUND error
  (caught by ERRSET in THMATCH1, causing match failure).

## SBCL invocation for tests

Always use `--disable-debugger --quit` when running SBCL non-interactively.
Without `--quit`, SBCL drops to the REPL after loading all `--load` files, waiting
for stdin — even if the loaded files contain `(sb-ext:exit)`. The `--quit` flag
ensures exit after all `--load` files are processed.

Test runs output to `clplnr_repo/runs/`.

## Assertion data structure

`(THASSERT (P A B))` stores `THTTL = (CONS '(P A B) property-list)` in the database.
For a plain assertion with no properties: `THTTL = ((P A B))`.
`THGOAL` returns this THTTL on success, so `(THGOAL (HUMAN SOCRATES))` returns
`((HUMAN SOCRATES))`, not `(HUMAN SOCRATES)`.

## THPROG return value

`(THPROG (vars) body...)` returns `THNOVAL` when the body exhausts without `THRETURN`.
`THNOVAL` is truthy (not nil), signaling "succeeded with no explicit value".

## CAADAHAR

Not a valid CL accessor. Appears in `thcondt` in the original. Needs investigation —
may be a CAR/CDR chain specific to the THCOND frame structure. Left as undefined
function stub; `thcondt` is not exercised in current tests.
