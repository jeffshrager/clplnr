# clplnr Implementation Plan

Date: 2026-05-13

## What plnr.181 actually is

- 2499 lines of MacLisp. Fully self-contained implementation with a property-list
  database, association-list variable bindings (THALIST), a continuation/backtracking
  stack (THTREE), and pattern matching.
- Every TH* operator is an FEXPR (receives unevaluated args) — these map to CL macros.
- Backtracking is driven by DEFPROP dispatch: each frame type on THTREE has a THFAIL
  handler and a THSUCCEED handler stored as properties.
- Database is indexed per-atom via property lists (THASSERTION, THANTE, THCONSE,
  THERASING).

## Key MacLisp -> CL translation challenges

- FEXPR / DEFUN foo FEXPR (args) body  ->  CL macros
- DEFPROP atom val indicator  ->  (setf (get 'atom 'indicator) 'value)
- SASSQ, MAKOBLIST, ERRSET, READCH, SUB1  ->  thin compat wrappers
- PURE/PAGEBPORG/LAPPURIFY, IOC Q, SSTATUS  ->  skip (ITS-specific)
- *CATCH/*THROW  ->  CL catch/throw (identical semantics, different syntax)

## nplnr.12 status

nplnr.12 is a design sketch for a continuation-passing rewrite using Lisp Machine
internals (DTP-EXTERNAL-VALUE-CELL, FUNCALL-ENV); not suitable as primary source.
It confirms the architecture but we translate plnr.181.

## Plan: 5 phases

### Phase 0 -- Repo scaffolding
Create clplnr_repo/ structure: ASDF system file, package definition, empty source
files. Decide on package name and symbol conventions (uppercase TH* names throughout).

### Phase 1 -- MacLisp compat layer (compat.lisp)
Thin shims only: DEFPROP macro, SASSQ, SUB1/ADD1, MAKOBLIST (walk cl:*package*),
THPUTPROP, and the $ read macro via set-macro-character wired to THREAD.
No more than ~50 lines.

### Phase 2 -- Global state (globals.lisp)
DEFVAR all the Planner globals: THTREE, THALIST, THVALUE, THEXP, THTRACE, THGENAME,
THLEVEL, THSTEP*, plus the THINIT function that resets them to starting values.

### Phase 3 -- Core translation (planner.lisp)
Translate plnr.181 function by function, in dependency order:

  1. Utilities: THPUSH, EVLIS, THPRINT2/C, THPOPT, THVAR, THVAL, THMATCH1
  2. Database: THADD, THREMOVE, THIP, THBA/THBAP, THMATCHLIST
  3. Variable binding: THBIND, THBI1, THGAL/THSGAL, THRPLACAS
  4. Operators (FEXPRs -> macros):
       THASSERT, THERASE, THGOAL, THFIND, THPROG, THAND, THOR, THCOND,
       THCONSE, THANTE, THERASING, THAMONG, THSETQ, THVSETQ,
       THSUCCEED, THFAIL, THRETURN, THBKPT, THMESSAGE
  5. Backtracking dispatch: THTRY1, THBRANCHUN, THPROGF/THPROGT,
       all the DEFPROP THFAIL/THSUCCEED pairs
  6. Top-level: THINIT, THERT, THSTATE

### Phase 4 -- Tests (tests/basic.lisp)
Working through the classic examples from the manual and from glmb.8's preamble:
  - Simple assert + goal: (HUMAN SOCRATES) -> (THGOAL (HUMAN SOCRATES))
  - Consequent theorem: (FALLIBLE $?X) <- (HUMAN $?X) -> (THGOAL (FALLIBLE TURING))
  - THFIND with backtracking
  - THPROG with THRETURN
  - Erase + re-goal

### Phase 5 -- Notes & seshsum
Write notes/translation_decisions.md recording every non-obvious MacLisp->CL
mapping as we go. Write seshsums/ entry at end of each session.
