# Canonical Source Directory: MITDDC_MicroPlanner_repo/plnr/3100090/

Date of decision: 2026-05-13

## The seven tape-image directories

The repo contains seven subdirectories under plnr/, each extracted from a
different ITS backup tape image. File dates are the original ITS timestamps
recovered by itstar.

| Dir      | File date range  | Highest plnr version | Notable readable text files |
|----------|-----------------|---------------------|-----------------------------|
| 701546   | Aug–Oct 1971    | plnr.171            | Everything has a |0 duplicate (macOS resource-fork artifact); all files binary |
| 3100154  | Sep 1971–Mar 1972 | plnr.180          | plnr.180 (ASCII), plnr.lap/olap; sparse |
| 3100015  | 1971–1973       | plnr.180            | plnr.180, plnr.lap/nlap/olap, eplnr1.lap (Planner-1 variant), format.plnr; also has plnr.fasl/unfasl (binary) |
| 7007554  | Jan 1977–Mar 1978 | plnr.181          | plnr.181, nplnr.11/12, np.11-13, glmb.7/8 |
| 7007839  | Jan 1977–Mar 1978 | plnr.181          | Byte-for-byte identical to 7007554; different tape, same snapshot |
| **3100090** | **1975–1981** | **plnr.181**      | **plnr.181, nplnr.12, np.25/26, nnplnr.3/4, qplnr.3/5, setthy.5/6, glmb.8, hk.1** |
| 3100146  | 1978–1982       | plnr.181            | plnr.181, np.33/35/36, qplnr.5; most other files binary (plnr.fasl, plnr.lrec, hecate.lrec, walt.lrec) |

## Key facts established by inspection

- All four copies of plnr.181 (in 3100090, 3100146, 7007554, 7007839) are
  byte-for-byte identical: 2499 lines, dated Jan 25 1978. This is the
  canonical final Micro-Planner source.
- plnr.unfasl in 3100146 is a FASL disassembly header (compiled March 8 1982),
  not source Lisp — not useful for porting.
- 7007554 and 7007839 are duplicate tape images of the same snapshot.
- The |0 files in 701546 are macOS HFS+/APFS alternate data stream artifacts
  from the itstar extraction; they can be ignored or deleted.

## Why 3100090 was chosen as canonical

3100090 has the richest set of readable Maclisp/Planner source files alongside
the canonical plnr.181:

  - nplnr.12    — "new planner" module
  - nnplnr.3/4  — "new new planner" extensions
  - np.25/26    — later new-planner patches
  - qplnr.3/5   — quick-planner variant
  - setthy.5/6  — set-theory theorem prover (Sussman)
  - glmb.8      — global variable bindings
  - hk.1        — hook utilities

This gives the most complete readable picture of the system as it stood circa
1978–1981, which is the target era for the clplnr_repo/ port.

The np.33/35/36 files in 3100146 (1981 dates) are accessible from that
directory if needed; they were not enough reason to make 3100146 canonical
given that most of its other files are compiled binaries.

## Next steps (as of session 1)

- Review clplnr_repo/ to understand what has already been started.
- Delete purely binary files from the repo (fasl, dump, qfasl, lrec, xfile,
  |0 duplicates, index files, ts.* dumps, nthtra.*, thtrac.*, setthy.3 binary,
  manual.xgp) to reduce noise before working.
- Use 3100090/plnr/ as the reference when writing CL wrappers in clplnr_repo/.
